
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function getGameCommentary(score: number, highScore: number, playerName: string): Promise<string> {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `The player "${playerName}" just finished a monochrome game called "Skull Eater". 
                The skull grows massive as it consumes blocks.
                Score (blocks eaten): ${score}. 
                High Score: ${highScore}. 
                Provide a very short (max 15 words), snarky or encouraging comment about their gluttony for data. Address them by name.`,
      config: {
        temperature: 0.9,
      }
    });

    return response.text || "CONSUMPTION TERMINATED.";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return score >= highScore ? `The void is full, ${playerName}.` : `Not enough consumption, ${playerName}.`;
  }
}
